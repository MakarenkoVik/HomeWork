from django.contrib import admin

from posts.models import Category, User, Post

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    pass

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ("first_name", "last_name")

@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ("title", "date_created", "post_category")