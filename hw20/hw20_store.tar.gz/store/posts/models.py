from django.core.validators import EmailValidator, RegexValidator
import re
from django.db import models


class Category(models.Model):
    category_title = models.CharField(max_length=30)
    def __str__(self):
        return f"{self.category_title}"

class User(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    gender = models.CharField(max_length=10)
    login = models.CharField(max_length=50, validators=[
        RegexValidator(
            regex=r"[A-Za-z]{6,}$""",
            message="Enter a valid email login",
            code="invalid",
            inverse_match=False,
            flags=re.IGNORECASE
        )
    ])
    email = models.CharField(max_length=50, null=True, validators=[
        EmailValidator(
            message="Enter a valid email address",
            code="invalid",
            allowlist=["localhost"]
        )
    ])
    register_dete = models.DateField()
    def __str__(self):
        return f"{self.first_name} {self.last_name}"

class Post(models.Model):
    title = models.CharField(max_length=100)
    date_created = models.DateField()
    content = models.TextField()
    post_author = models.ForeignKey(User, on_delete=models.CASCADE)
    post_category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True)
    def __str__(self):
        return f"{self.title} - {self.date_created} - {self.post_category.category_title}"
