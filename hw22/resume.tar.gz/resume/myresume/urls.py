from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="class_view"),
    path("contacts/", views.contacts, name="contacts"),
    path("experience/", views.experience, name="experience"),
    path("programming_skills/", views.programming_skills, name="programming_skills"),
]