from django.shortcuts import render
from datetime import datetime

def index(request):
    date = datetime.now()
    context = {"date": date}
    return render(request, 'myresume/home.html', context)

def contacts(request):
    return render(request, 'myresume/contacts.html')

def experience(request):
    return render(request, 'myresume/experience.html')

def programming_skills(request):
    return render(request, 'myresume/programming_skills.html')