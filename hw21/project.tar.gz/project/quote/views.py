from django.shortcuts import render
from django.http import HttpResponse, HttpRequest, JsonResponse
from django.views.generic import View
import requests


def func_factorial(request: HttpRequest, *args, **kwargs):
    number = int(request.GET.get("number", 1))
    factorial = 1
    for i in range(2, number + 1):
        factorial *= i
    return JsonResponse({"number": number, "factorial": factorial})
 

class MyClassQuoteView(View):

    def get (self, request, *args, **kwargs):
        number = int(request.GET.get("number", 1))
        messages = []
        for i in range(0, number):
            messages.append(requests.get("https://api.kanye.rest").json()["quote"])
        d = {"messages": messages}
        return render(request, "quote/quotes.html", context=d)
