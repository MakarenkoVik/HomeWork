from django.urls import path
from . import views


urlpatterns = [
    path("home/", views.func_factorial, name="home"),
    path("class-home/", views.MyClassQuoteView.as_view(), name="class-home")
]